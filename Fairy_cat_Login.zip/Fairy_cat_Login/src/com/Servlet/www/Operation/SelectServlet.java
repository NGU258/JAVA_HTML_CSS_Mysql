package com.Servlet.www.Operation;

import com.Utils.Utilsimpl;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * ██████████████████████████████████████████████████████████████████████████████████████
 * ███████████████████████████▓▓▓▓▓▓▓▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓▓▓╬╬╬╬╬╬▓███████████████████████
 * ███████████████████████████▓███████▓▓╬╬╬╬╬╬╬╬╬╬╬╬▓███▓▓▓▓█▓╬╬╬▓███████████████████████
 * ███████████████████████████████▓█████▓▓╬╬╬╬╬╬╬╬▓███▓╬╬╬╬╬╬╬▓╬╬▓███████████████████████
 * ████████████████████████████▓▓▓▓╬╬▓█████╬╬╬╬╬╬███▓╬╬╬╬╬╬╬╬╬╬╬╬╬███████████████████████
 * ███████████████████████████▓▓▓▓╬╬╬╬╬╬▓██╬╬╬╬╬╬▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓███████████████████████
 * ████████████████████████████▓▓▓╬╬╬╬╬╬╬▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓███████████████████████
 * ███████████████████████████▓█▓███████▓▓███▓╬╬╬╬╬╬▓███████▓╬╬╬╬▓███████████████████████
 * ████████████████████████████████████████▓█▓╬╬╬╬╬▓▓▓▓▓▓▓▓╬╬╬╬╬╬╬███████████████████████
 * ███████████████████████████▓▓▓▓▓▓▓╬╬▓▓▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓███████████████████████
 * ████████████████████████████▓▓▓╬╬╬╬▓▓▓▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓███████████████████████
 * ███████████████████████████▓█▓▓▓▓▓▓▓▓▓▓▓▓▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓███████████████████████
 * █████████████████████████████▓▓▓▓▓▓▓▓█▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓███████████████████████
 * █████████████████████████████▓▓▓▓▓▓▓██▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬████████████████████████
 * █████████████████████████████▓▓▓▓▓████▓▓▓█▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬████████████████████████
 * ████████████████████████████▓█▓▓▓▓██▓▓▓▓██╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬████████████████████████
 * ████████████████████████████▓▓███▓▓▓▓▓▓▓██▓╬╬╬╬╬╬╬╬╬╬╬╬█▓╬▓╬╬▓████████████████████████
 * █████████████████████████████▓███▓▓▓▓▓▓▓▓████▓▓╬╬╬╬╬╬╬█▓╬╬╬╬╬▓████████████████████████
 * █████████████████████████████▓▓█▓███▓▓▓████╬▓█▓▓╬╬╬▓▓█▓╬╬╬╬╬╬█████████████████████████
 * ██████████████████████████████▓██▓███████▓╬╬╬▓▓╬▓▓██▓╬╬╬╬╬╬╬▓█████████████████████████
 * ███████████████████████████████▓██▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓╬╬╬╬╬╬╬╬╬╬╬██████████████████████████
 * ███████████████████████████████▓▓██▓▓▓▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓██████████████████████████
 * ████████████████████████████████▓▓▓█████▓▓╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬╬▓███████████████████████████
 * █████████████████████████████████▓▓▓█▓▓▓▓▓███▓╬╬╬╬╬╬╬╬╬╬╬▓████████████████████████████
 * ██████████████████████████████████▓▓▓█▓▓▓╬▓██╬╬╬╬╬╬╬╬╬╬╬▓█████████████████████████████
 * ███████████████████████████████████▓▓█▓▓▓▓███▓╬╬╬╬╬╬╬╬╬▓██████████████████████████████
 * ██████████████████████████████████████▓▓▓███▓▓╬╬╬╬╬╬╬╬████████████████████████████████
 * ███████████████████████████████████████▓▓▓██▓▓╬╬╬╬╬╬▓█████████████████████████████████
 * 让风告诉你：
 * 当你的天空突然下起了大雨，那是我在为你炸乌云~
 * 当你的天空突然下起了大雨，那是本尊为你炸乌云~
 * 当你的天空突然下起了大雨，那是本尊帮你炸乌云~
 * …………
 * 作者：元气小喵仙。欢迎来到我的编程小世界，尽情在此遨游吧！
 */
public class SelectServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String name = req.getParameter("name");
        String all = req.getParameter("all");

        try {

            Connection cn = Utilsimpl.getConnection();
            String selSql;

            if(all==null)
               selSql="select * from lyq where name=\'"+name+"\'";
            else selSql="select * from lyq";

            PrintWriter wr = resp.getWriter();
            PreparedStatement pt = cn.prepareStatement(selSql);

            ResultSet rt = pt.executeQuery();
            wr.write("<table border='1' align=\"center\" bgcolor=\"blue\">");
            wr.write("<caption><center style=\"color:gold \">查 询 结 果</center></caption>");
            wr.write("<tr color=\"red\"><th>编号</th><th>姓名</th><th>密码</th><th>年龄</th><th>性别</th><th>地址</th></tr>");
            Boolean sign=true;
            while(rt.next())
            {
                sign=false;
                Integer Id = rt.getInt("id");
                String Name = rt.getString("name");
                String pwd = rt.getString("pwd");
                Integer Age = rt.getInt("age");
                String Sex = rt.getString("sex");
                String Address = rt.getString("address");

                wr.write("<tr color=\"purple\">");
                wr.write("<th>"+Id+"</th>");
                wr.write("<th>"+Name+"</th>");
                wr.write("<th>"+pwd+"</th>");
                wr.write("<th>"+Age+"</th>");
                wr.write("<th>"+Sex+"</th>");
                wr.write("<th>"+Address+"</th>");
                wr.write("</tr>");
            }

            wr.write("</table>");

            if(sign)
                wr.write("<h2 style=\"color:purple; \"><center>阁下，当前数据库中没有任何数据呜呜~</center></h2>");
            wr.write("<h2 style=\"color:red; \"><center><a href=\"..\\HTML\\LoginSuccess.html\">点俺返回喵~</a></center></h2>");
            wr.flush();

            Utilsimpl.destroyConnection(cn,pt,rt);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void init(ServletConfig config) throws ServletException {

    }
}
